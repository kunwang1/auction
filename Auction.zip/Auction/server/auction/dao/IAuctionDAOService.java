package com.auction.dao;

import com.auction.model.AuctionItem;
import com.auction.model.Item;

import java.util.List;

/**
 * Auction data access service interface, specifying the APIs for the data access and manipulation.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public interface IAuctionDAOService {

    void bidAuctionItem(final int auctionItemId,
                        final double maxBidAmount,
                        final String bidderName,
                        double currentBid,
                        double reservePrice);

    AuctionItem createAuctionItem(final int itemId,
                                  final double reservePrice);

    boolean didUserBidAuction(String bidderName,
                              int auctionItemId);

    List<AuctionItem> getAllAuctionItems();

    AuctionItem getAuctionItem(final int auctionItemId);

    List<Item> getItems();

    double getNextMaxBidAmount(String leadingBidder,
                               int auctionItemId);

    String[] retrieveLeadingBidder(int auctionItemId);

}
