package com.auction.dao;

/**
 * AuctionDAOServiceManager is a singleton to return an IAuctionDAOService object.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public class AuctionDAOServiceManager {

    private static IAuctionDAOService auctionDAOService;

    public static IAuctionDAOService getAuctionDAOService() {
        if (auctionDAOService == null) {
            auctionDAOService = new AuctionDAOServiceImpl();
        }

        return auctionDAOService;
    }

    private AuctionDAOServiceManager() {
    }

}
