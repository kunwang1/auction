package com.auction.dao;

import com.auction.model.AuctionItem;
import com.auction.model.Item;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * A specific implementation of the auction DAO service interface.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public class AuctionDAOServiceImpl implements IAuctionDAOService {

    private static String connectionStr =
            "jdbc:mysql://localhost:3306/siegle?" + "user=root&password=siegle2012";
    private Connection conn = null;
    private Statement stmt = null;

    private ResultSet rs = null;

    // Package only access - to prevent other classes from instantiating this class outside of the
    // package
    AuctionDAOServiceImpl() {

    }

    @Override
    public void bidAuctionItem(int auctionItemId,
                               double maxBidAmount,
                               String bidderName,
                               double currentBid,
                               double reservePrice) {
        try {

            conn = this.getConnection();
            conn.setAutoCommit(false);

            stmt = conn.createStatement();
            String sql = null;
            if (currentBid < maxBidAmount) {
                // update the current bid to maxBidAmount in the DB
                sql = "update auctionitems set currentBid = " + maxBidAmount
                        + "where auctionItemId = " + auctionItemId;

                stmt.executeUpdate(sql);
            }

            // log this bidding in the DB
            rs = stmt.executeQuery("select max(biddingId) as lastId from biddinghistory");

            int biddingId = 0;
            while (rs.next()) {
                int lastId = rs.getInt("lastId");
                biddingId = lastId + 1;
                break;
            }

            sql = "insert into biddinghistory (`auctionItemId`, `maxBidAmount`, `bidderName`, `biddingId`) values (?,?,?,?)";

            PreparedStatement preparedStmt = conn.prepareStatement(sql);
            preparedStmt.setInt(1, auctionItemId);
            preparedStmt.setDouble(2, maxBidAmount);
            preparedStmt.setString(3, bidderName);
            preparedStmt.setInt(4, biddingId);
            preparedStmt.executeUpdate();

            conn.commit();

        } catch (SQLException ex) {
            // handle any errors
            ex.printStackTrace();

        } finally {
            closeConnection();
        }
    }

    @Override
    public AuctionItem createAuctionItem(int itemId,
                                         double reservePrice) {

        try {

            double currentBid = 0.00;
            int auctionItemId = 0;

            String sql =
                    "insert into auctionitems ( `auctionItemId`, `currentBid`, `reservePrice`, `itemId`) values (?,?,?,?)";

            conn = this.getConnection();

            stmt = conn.createStatement();
            rs = stmt.executeQuery("select max(auctionItemId) as lastId from auctionitems");

            while (rs.next()) {
                int lastId = rs.getInt("lastId");
                auctionItemId = lastId + 1;
                break;
            }

            PreparedStatement preparedStmt = conn.prepareStatement(sql);
            preparedStmt.setInt(1, auctionItemId);
            preparedStmt.setDouble(2, currentBid);
            preparedStmt.setDouble(3, reservePrice);
            preparedStmt.setInt(4, itemId);

            preparedStmt.executeUpdate();

            return new AuctionItem(auctionItemId, currentBid, reservePrice, new Item(itemId, ""));

        } catch (SQLException ex) {
            // handle any errors
            ex.printStackTrace();

        } finally {
            closeConnection();
        }

        return null;
    }

    @Override
    public boolean didUserBidAuction(String bidderName,
                                     int auctionItemId) {
        try {
            conn = getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(
                    "select bidderName from biddinghistory where auctionItemId = " + auctionItemId);
            while (rs.next()) {
                if (rs.getString("bidderName").equals(bidderName)) {
                    return true;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }
        return false;
    }

    @Override
    public List<AuctionItem> getAllAuctionItems() {

        List<AuctionItem> auctionItems = new ArrayList<AuctionItem>();
        try {

            conn = this.getConnection();

            stmt = conn.createStatement();
            rs = stmt.executeQuery(
                    "select auctionitems.auctionItemId as auctionItemId, auctionitems.currentBid as currentBid, auctionitems.reservePrice as reservePrice, "
                            + "auctionitems.itemId as itemId, items.description as description from auctionitems, items where auctionitems.itemId = items.itemId;");

            while (rs.next()) {
                int auctionItemId = rs.getInt("auctionItemId");
                double currentBid = rs.getDouble("currentBid");
                double reservePrice = rs.getDouble("reservePrice");
                int itemId = rs.getInt("itemId");
                String description = rs.getString("description");
                auctionItems.add(new AuctionItem(auctionItemId, currentBid, reservePrice,
                        new Item(itemId, description)));

            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }

        return auctionItems;
    }

    @Override
    public AuctionItem getAuctionItem(int auctionItemId) {
        try {

            conn = getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(
                    "select auctionitems.auctionItemId as auctionItemId, auctionitems.currentBid as currentBid, auctionitems.reservePrice as reservePrice, "
                            + "auctionitems.itemId as itemId, items.description as description from auctionitems, items "
                            + "where auctionItems.auctionItemId = " + auctionItemId
                            + " and auctionitems.itemId = items.itemId;");

            while (rs.next()) {
                double currentBid = rs.getDouble("currentBid");
                double reservePrice = rs.getDouble("reservePrice");
                int itemId = rs.getInt("itemId");
                String description = rs.getString("description");

                return new AuctionItem(auctionItemId, currentBid, reservePrice,
                        new Item(itemId, description));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }

        return null;
    }

    @Override
    public List<Item> getItems() {
        List<Item> items = new ArrayList<Item>();
        try {

            conn = getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from items;");

            while (rs.next()) {
                int id = rs.getInt("itemId");
                String desc = rs.getString("description");
                items.add(new Item(id, desc));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }

        return items;
    }

    @Override
    public double getNextMaxBidAmount(String leadingBidder,
                                      int auctionItemId) {
        double nextMaxAmount = 0;
        try {

            conn = this.getConnection();

            String sql = "select max(maxBidAmount) as maxBidAmount from biddinghistory "
                    + "where auctionItemId = " + auctionItemId + " and bidderName != '"
                    + leadingBidder + "'";

            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                nextMaxAmount = rs.getDouble("maxBidAmount");
                break;
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }

        return nextMaxAmount;
    }

    @Override
    public String[] retrieveLeadingBidder(int auctionItemId) {

        try {
            conn = this.getConnection();
            String sql =
                    "select bidderName, maxBidAmount from biddinghistory where auctionItemId = "
                            + auctionItemId + " order by maxBidAmount desc limit 1";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {

                return new String[]{rs.getString("bidderName"), rs.getDouble("maxBidAmount") + ""};
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }
        return null;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private Connection getConnection() {
        try {
            return DriverManager.getConnection(connectionStr);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return null;
    }
}
