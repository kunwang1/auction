package com.auction.api;

import com.auction.model.AuctionItem;
import com.auction.model.AuctionServiceManager;
import com.auction.model.IAuctionService;
import com.auction.model.Item;

import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * The interface for the auction REST APIs. URLs are consistent with the requirement specifications.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */

@Controller
public class AuctionController {

    private IAuctionService auctionService;

    public AuctionController() {
        auctionService = AuctionServiceManager.getAuctionService();
    }

    /**
     * Bid a specific auction item.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/bids", method = RequestMethod.POST)
    public void bidAuctionItem(final HttpServletRequest request,
                               final HttpServletResponse response) {

        try {
            String reqBody =
                    request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));

            JSONObject jsonObj = new JSONObject(reqBody);

            int auctionItemId = jsonObj.getInt("auctionItemId");

            double maxBidAmount = jsonObj.getDouble("maxBidAmount");

            String bidderName = jsonObj.getString("bidderName");

            String message = auctionService.bidAuctionItem(auctionItemId, maxBidAmount, bidderName);

            if (message != null) {
                response.sendError(200, message);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /**
     * Close/stop bidding a specific auction item.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/stopbidding", method = RequestMethod.GET)
    public void closeBidding(final HttpServletRequest request,
                             final HttpServletResponse response) {

        int auctionItemId = Integer.parseInt(request.getParameter("auctionItemId"));

        auctionService.closeBidding(auctionItemId);
    }

    /**
     * Create an auction item.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/auctionItems", method = RequestMethod.POST)
    public @ResponseBody AuctionItem createAuctionItem(final HttpServletRequest request,
                                                       final HttpServletResponse response) {

        try {
            String reqBody =
                    request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));

            JSONObject jsonObj = new JSONObject(reqBody);

            double reservePrice = jsonObj.getDouble("reservePrice");
            int itemId = jsonObj.getJSONObject("item").getInt("itemId");

            return auctionService.createAuctionItem(itemId, reservePrice);

        } catch (Exception ex) {
            // handle any errors
            ex.printStackTrace();
        }

        return null;
    }

    /**
     * Get all auction items.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/auctionItems", method = RequestMethod.GET)
    public @ResponseBody List<AuctionItem> getAllAuctionItems(final HttpServletRequest request,
                                                              final HttpServletResponse response) {

        return auctionService.getAllAuctionItems();

    }

    /**
     * Get a specific auction item by its ID.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/auctionItems/{auctionItemId}", method = RequestMethod.GET)
    public @ResponseBody AuctionItem getAuctionItem(final HttpServletRequest request,
                                                    final HttpServletResponse response,
                                                    final @PathVariable("auctionItemId") String auctionItemId) {

        return auctionService.getAuctionItem(Integer.parseInt(auctionItemId));
    }

    /**
     * Get all items.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/items", method = RequestMethod.GET)
    public @ResponseBody List<Item> getItems(final HttpServletRequest request,
                                             final HttpServletResponse response) {

        return auctionService.getItems();
    }

    /**
     * Register a bidder thread to the server message broadcasting.
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/serverMessageRegistration", method = RequestMethod.GET)
    public void registerServerMessages(final HttpServletRequest request,
                                       final HttpServletResponse response) {

        try {
            String bidderName = request.getParameter("bidderName");
            String message = auctionService.registerServerMessages(bidderName);

            if (message != null) {
                response.sendError(200, message);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
