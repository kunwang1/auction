package com.auction.model;

/**
 * Class representing an item
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public class Item {
    private int itemId;
    private String description;

    public Item(int itemId, String description) {
        this.itemId = itemId;
        this.description = description;

    }

    public String getDescription() {
        return description;
    }

    public int getItemId() {
        return itemId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

}
