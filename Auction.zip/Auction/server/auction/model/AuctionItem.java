package com.auction.model;

/**
 * Class representing an auction item
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public class AuctionItem {

    private int auctionItemId;
    private double currentBid;
    private double reservePrice;
    private Item item;

    public AuctionItem(int auctionItemId, double currentBid, double reservePrice, Item item) {
        this.auctionItemId = auctionItemId;
        this.currentBid = currentBid;
        this.reservePrice = reservePrice;
        this.item = item;
    }

    public int getAuctionItemId() {
        return auctionItemId;
    }

    public double getCurrentBid() {
        return currentBid;
    }

    public Item getItem() {
        return item;
    }

    public double getReservePrice() {
        return reservePrice;
    }

    public void setAuctionItemId(int auctionItemId) {
        this.auctionItemId = auctionItemId;
    }

    public void setCurrentBid(double currentBid) {
        this.currentBid = currentBid;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public void setReservePrice(double reservePrice) {
        this.reservePrice = reservePrice;
    }

}
