package com.auction.model;

import com.auction.dao.AuctionDAOServiceManager;
import com.auction.dao.IAuctionDAOService;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A specific implementation of the auction service interface.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public class AuctionServiceImpl implements IAuctionService {

    private int closedAuctionItemId = 0;

    private double actualAmountToPay = 0;

    private int currentAuctionItemId = 0;

    private IAuctionDAOService auctionDAOService;

    private Set<String> loggedInBidders = new HashSet<>();

    private int closeBiddingNotificationCount = 0;

    // Package only access - to prevent other classes from instantiating this class outside of the
    // package
    AuctionServiceImpl() {
        auctionDAOService = AuctionDAOServiceManager.getAuctionDAOService();
    }

    @Override
    public synchronized String bidAuctionItem(final int auctionItemId,
                                              final double maxBidAmount,
                                              final String bidderName) {
        setCurrentAuctionItemId(auctionItemId);

        double currentBid = getAuctionItem(auctionItemId).getCurrentBid();
        double reservePrice = getAuctionItem(auctionItemId).getReservePrice();

        auctionDAOService.bidAuctionItem(auctionItemId,
                maxBidAmount,
                bidderName,
                currentBid,
                reservePrice);

        String[] leadingBidderInfo = retrieveLeadingBidderInfo(auctionItemId);
        if (leadingBidderInfo[0].equals(bidderName)) {
            notifyAll();
        }

        if (maxBidAmount < reservePrice) {
            return "Your bid amount must be at least " + reservePrice + ".";
        } else {
            return "Your bid was successfully submitted.";
        }
    }

    @Override
    public synchronized void closeBidding(final int auctionItemId) {

        String leadingBidder = retrieveLeadingBidderInfo(auctionItemId)[0];

        double nextMaxAmount = auctionDAOService.getNextMaxBidAmount(leadingBidder, auctionItemId);
        actualAmountToPay = nextMaxAmount + 1;
        closedAuctionItemId = auctionItemId;
        notifyAll();

    }

    @Override
    public AuctionItem createAuctionItem(final int itemId,
                                         final double reservePrice) {
        return auctionDAOService.createAuctionItem(itemId, reservePrice);
    }

    @Override
    public List<AuctionItem> getAllAuctionItems() {
        List<AuctionItem> auctionItems = auctionDAOService.getAllAuctionItems();
        return auctionItems;
    }

    @Override
    public AuctionItem getAuctionItem(final int auctionItemId) {

        return auctionDAOService.getAuctionItem(auctionItemId);
    }

    @Override
    public List<Item> getItems() {
        return auctionDAOService.getItems();
    }

    @Override
    public synchronized String registerServerMessages(String bidderName) {
        try {
            loggedInBidders.add(bidderName);
            wait();

            boolean userBidAuction = false;
            String leadingBidderName = null;

            if (closedAuctionItemId != 0) {

                closeBiddingNotificationCount++;

                userBidAuction =
                        auctionDAOService.didUserBidAuction(bidderName, closedAuctionItemId);

                if (userBidAuction) {

                    leadingBidderName = retrieveLeadingBidderInfo(closedAuctionItemId)[0];
                    String message = null;

                    if (bidderName.equals(leadingBidderName)) {
                        message = "Bidding is closed for auction " + closedAuctionItemId
                                + ". Contragulations " + leadingBidderName
                                + ", you only need to pay " + actualAmountToPay
                                + " to win this auction item.";
                    } else {
                        message = "Bidding is closed for auction " + closedAuctionItemId
                                + ". Sorry " + bidderName + ", you lost this bidding.";
                    }

                    if (closeBiddingNotificationCount == loggedInBidders.size()) {

                        // All bidders are notified of the auction close.
                        closedAuctionItemId = 0;
                        actualAmountToPay = 0;
                        closeBiddingNotificationCount = 0;
                    }

                    return message;
                }

            } else {

                userBidAuction =
                        auctionDAOService.didUserBidAuction(bidderName, currentAuctionItemId);

                leadingBidderName = retrieveLeadingBidderInfo(currentAuctionItemId)[0];
                if (userBidAuction) {

                    if (!leadingBidderName.equals(bidderName)) {
                        return bidderName + ", you are out bid. Sorry.";
                    }
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;

    }

    private String[] retrieveLeadingBidderInfo(int auctionItemId) {

        return auctionDAOService.retrieveLeadingBidder(auctionItemId);
    }

    private synchronized void setCurrentAuctionItemId(final int currentAuctionItemId) {
        this.currentAuctionItemId = currentAuctionItemId;
    }

}
