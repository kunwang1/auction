package com.auction.model;

import java.util.List;

/**
 * Auction service interface, specifying the APIs for business logic and functionality.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public interface IAuctionService {

    String bidAuctionItem(final int auctionItemId,
                          final double maxBidAmount,
                          final String bidderName);

    void closeBidding(final int auctionItemId);

    AuctionItem createAuctionItem(final int itemId,
                                  final double reservePrice);

    List<AuctionItem> getAllAuctionItems();

    AuctionItem getAuctionItem(final int auctionItemId);

    List<Item> getItems();

    String registerServerMessages(String bidderName);

}
