package com.auction.model;

/**
 * AuctionServiceManager is a singleton to return an IAuctionService object.
 *
 * @author Kun Wang, kun.wang@ymail.com
 */
public class AuctionServiceManager {

    private static IAuctionService auctionService;

    public static IAuctionService getAuctionService() {
        if (auctionService == null) {
            auctionService = new AuctionServiceImpl();
        }

        return auctionService;
    }

    private AuctionServiceManager() {
    }

}
