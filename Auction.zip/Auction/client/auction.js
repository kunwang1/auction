var user;
var itemsTable;	
var auctionItemsTable;	

/**
	System login function.
*/	
function login()
{
	user = document.getElementById( "userName" );		
	itemsTable = document.getElementById( "items" );	
	auctionItemsTable = document.getElementById( "auctionItems" );
	if ( user == undefined || user.value === null || user.value === "" )
	{
		window.alert( "Please enter your user name to login." );
	}
	else
	{
		if ( user.value === "admin" )
		{
			loadItems();
		}
		else
		{
			loadAuctionsButton.firstChild.nodeValue = "Refresh Auction List";
			registerServerMessages( user.value );
			loadAuctionItems();					
		}		
	}		
}

/**
	Display the existing items in a table so that the admin can post them for auction.
*/
function loadItems()
{
	// Remove the existing table rows (if any) before constructing it.
	while ( itemsTable !== undefined && itemsTable !== null && itemsTable.firstChild ) 
	{
		itemsTable.removeChild( itemsTable.firstChild );
	}
	
	var url = "http://localhost:8888/items"
	var xhr = new XMLHttpRequest();
	var method = "GET";
	xhr.open( method, url );
	xhr.setRequestHeader( "Content-Type", "application/json;charset=UTF-8" );  
	xhr.responseType = "json";
	xhr.onload = ( function () 
		{
			if ( xhr.response !== undefined && xhr.response != null && ( xhr.status === 200 || xhr.status === 0 ) ) 
			{ 		
				// Construct the table headers
				let header = document.createElement('tr');
					
				let itemIdHeader = document.createElement('th');
				let itemIdHeaderTxt = document.createTextNode( "Item ID" );  
				itemIdHeader.appendChild( itemIdHeaderTxt );
				header.appendChild( itemIdHeader );
				
				let descHeader = document.createElement('th');
				let descHeaderTxt = document.createTextNode( "Description" );  
				descHeader.appendChild( descHeaderTxt );
				header.appendChild( descHeader );
				
				let reservePriceHeader = document.createElement('th');
				let reservePriceHeaderTxt = document.createTextNode( "Reserve Price" );  
				reservePriceHeader.appendChild( reservePriceHeaderTxt );
				header.appendChild( reservePriceHeader );
				
				itemsTable.appendChild( header );
				
				// Construct the table rows based on the dataset returned from the DB
				for ( var i = 0; i < xhr.response.length; i++ )
				{
					let row = document.createElement( 'tr' );
					
					let itemId = document.createElement( 'td' );
					let itemIdTxt = document.createTextNode( xhr.response[i].itemId );  
					itemId.appendChild( itemIdTxt );
					row.appendChild( itemId );						
					
					let description = document.createElement( 'td' );
					let descriptionTxt = document.createTextNode( xhr.response[i].description );  
					description.appendChild( descriptionTxt );
					row.appendChild( description );						
					
					let reservePrice = document.createElement( 'td' );
					reservePrice.contentEditable = true;
					let reservePriceTxt = document.createTextNode( "0.00" );  
					reservePrice.appendChild( reservePriceTxt );
					row.appendChild( reservePrice );						
					
					// A button to allow the admin to post an item for auction, along with a 
					// reserve price.
					let postButton = document.createElement( "button" );
					let postButtonTxt = document.createTextNode( "Post for Auction" );  
					postButton.appendChild( postButtonTxt );
					row.appendChild( postButton );					
					postButton.addEventListener( "click", function(){
						if ( reservePrice.value <= 0 )
						{
							window.alert( "Reserve price must be greater than 0." );
							return;
						}
						postForAuction( reservePriceTxt.nodeValue, itemIdTxt.nodeValue, descriptionTxt.nodeValue );
					});
					
					itemsTable.appendChild( row );
				}				
				
				itemsTable.appendChild( document.createElement( 'br' ) );					
				itemsTable.appendChild( document.createElement( 'br' ) );
			}
			else 
			{       
			}
		} ).bind( this );

		xhr.onerror = function () 
		{
		};   
  
	xhr.send( null ); 
}

/**
	Show the existing auction items in a table so that the bidder can bid one or more of the items.
*/
function loadAuctionItems()
{
	if ( user === undefined || user.value === null || user.value === "" )
	{
		window.alert( "Please login first." );
		return;
	}
	
	// Remove the existing table rows (if any) before constructing it.
	loadAuctionsButton.firstChild.nodeValue = "Refresh Auction List";	
	while ( auctionItemsTable !== undefined && auctionItemsTable !== null && auctionItemsTable.firstChild ) 
	{
		auctionItemsTable.removeChild( auctionItemsTable.firstChild );
	}
	
	var url = "http://localhost:8888/auctionItems";
	var xhr = new XMLHttpRequest();
	var method = "GET";
	xhr.open( method, url );
	xhr.setRequestHeader( "Content-Type", "application/json;charset=UTF-8" );  
	xhr.responseType = "json";
	xhr.onload = ( function () 
		{
			if ( xhr.response !== undefined && xhr.response != null && ( xhr.status === 200 || xhr.status === 0 ) ) 
			{ 
				// Construct the table headers
				let header = document.createElement('tr');
					
				let auctionItemIdHeader = document.createElement( 'th' );
				let auctionItemIdHeaderTxt = document.createTextNode( "Auction Item ID" );  
				auctionItemIdHeader.appendChild( auctionItemIdHeaderTxt );
				header.appendChild( auctionItemIdHeader );
				
				let currentBidHeader = document.createElement( 'th' );
				let currentBidHeaderTxt = document.createTextNode( "Current Bid" );  
				currentBidHeader.appendChild( currentBidHeaderTxt );
				header.appendChild( currentBidHeader );
				
				let reservePriceHeader = document.createElement( 'th' );
				let reservePriceHeaderTxt = document.createTextNode( "Reserve Price" );  
				reservePriceHeader.appendChild( reservePriceHeaderTxt );
				header.appendChild( reservePriceHeader );					
				
				let itemIdHeader = document.createElement( 'th' );
				let itemIdHeaderTxt = document.createTextNode( "Item ID" );  
				itemIdHeader.appendChild( itemIdHeaderTxt );
				header.appendChild( itemIdHeader );
				
				let descHeader = document.createElement( 'th' );
				let descHeaderTxt = document.createTextNode( "Description" );  
				descHeader.appendChild( descHeaderTxt );
				header.appendChild( descHeader );	
				
				auctionItemsTable.appendChild( header );
				
				// Construct the table rows based on the dataset returned from the DB
				if ( user.value !== "admin" )
				{
					let maxBidAmountHeader = document.createElement( 'th' );
					let maxBidAmountHeaderTxt = document.createTextNode( "Max Bid Amount" );  
					maxBidAmountHeader.appendChild( maxBidAmountHeaderTxt );
					header.appendChild( maxBidAmountHeader );	
				}							
					
				for ( var i = 0; i < xhr.response.length; i++ )
				{
					let row = document.createElement( 'tr' );
					
					let auctionItemId = document.createElement( 'td' );
					let auctionItemIdTxt = document.createTextNode( xhr.response[i].auctionItemId );  
					auctionItemId.appendChild( auctionItemIdTxt );
					row.appendChild( auctionItemId );
					
					let currentBid = document.createElement( 'td' );
					let currentBidTxt = document.createTextNode( xhr.response[i].currentBid );  
					currentBid.appendChild( currentBidTxt );
					row.appendChild( currentBid );
					
					let reservePrice = document.createElement( 'td' );
					let reservePriceTxt = document.createTextNode( xhr.response[i].reservePrice  );  
					reservePrice.appendChild( reservePriceTxt );
					row.appendChild( reservePrice );
					
					let itemId = document.createElement( 'td' );
					let itemIdTxt = document.createTextNode( xhr.response[i].item.itemId );  
					itemId.appendChild( itemIdTxt );
					row.appendChild( itemId );						
					
					let description = document.createElement( 'td' );
					let descriptionTxt = document.createTextNode( xhr.response[i].item.description );  
					description.appendChild( descriptionTxt );
					row.appendChild( description );			
					
					auctionItemsTable.appendChild( row );					
					
					if ( user.value === "admin" )
					{
						// The admin user will see a "Stop Bidding" command for each auction item
						let stopBiddingButton = document.createElement( "button" );
						let stopBiddingButtonTxt = document.createTextNode( "Stop Bidding" );  
						stopBiddingButton.appendChild( stopBiddingButtonTxt );
						row.appendChild( stopBiddingButton );					
						stopBiddingButton.addEventListener( "click", function(){
							stopBidding( auctionItemIdTxt.nodeValue );
						});
					}	
					else
					{
						// The "Bid This Item" command will allow a bidder to bid an auction item 
						// with a maximum bid amount.
						let maxBidAmount = document.createElement( 'td' );
						maxBidAmount.contentEditable = true;
						let maxBidAmountTxt = document.createTextNode( "0.00" );  
						maxBidAmount.appendChild( maxBidAmountTxt );	
						row.appendChild( maxBidAmount );	
						
						let bidButton = document.createElement( "button" );
						let bidButtonText = document.createTextNode( "Bid This Item" );  
						bidButton.appendChild( bidButtonText );
						row.appendChild( bidButton );
						bidButton.addEventListener( "click", function(){
							if ( new Number( maxBidAmountTxt.nodeValue ) <= new Number ( currentBidTxt.nodeValue ) )
							{
								window.alert( "Your maximum offer must be higher than the current bid " + currentBidTxt.nodeValue + ".");
							}
							else
							{								
								bidItem( auctionItemIdTxt.nodeValue, maxBidAmountTxt.nodeValue, user.value );
							}
							
							
						});
					}
				}					
			}
			else 
			{       
			}
		} ).bind( this );

		xhr.onerror = function () 
		{
		};   
  
	xhr.send( null ); 
}

/**
	Bid an auction item given the auction item id, maximum bid amount, and bidder's name
*/
function bidItem(auctionItemId, maxBidAmount, bidderName)
{
	var url = "http://localhost:8888/bids";        
	var xhr = new XMLHttpRequest();
	var method = "POST"
	xhr.open( method, url );
	xhr.setRequestHeader( "Content-Type", "application/json;charset=UTF-8" );  
	xhr.responseType = "json";
	xhr.onload = ( function () 
			{
				if ( xhr.status === 200 || xhr.status === 0 ) 
				{ 					
					if ( xhr.statusText !== undefined && xhr.statusText !== null )
					{
						if ( xhr.statusText !== 'OK' )
						{
							window.alert( xhr.statusText );
						}
						else
						{
							window.alert( "Your bid is successfully submitted." );
						}
					}
				}
				else 
				{       
				}
			} ).bind( this );

			xhr.onerror = function () 
			{
			};
  
  var request = {
		  "auctionItemId": auctionItemId,         
		 "maxBidAmount": maxBidAmount,
		 "bidderName": bidderName
	  };
  
  xhr.send( JSON.stringify( request ) );
}

/**
	Register a bidder to the server messages - a long-polling method to broadcast server events to clients
*/
function registerServerMessages(bidderName)
{
	var url = "http://localhost:8888/serverMessageRegistration?bidderName=" + bidderName;        
	var xhr = new XMLHttpRequest();
	var method = "GET"
	xhr.open( method, url );
	xhr.setRequestHeader( "Content-Type", "application/json;charset=UTF-8" );  
	xhr.responseType = "json";
	xhr.onload = ( function () 
			{
				if ( xhr.status === 200 || xhr.status === 0 ) 
				{
					
					if ( xhr.statusText !== undefined && xhr.statusText !== null )
					{
						if ( xhr.statusText !== 'OK' )
						{
							window.alert( xhr.statusText );
							
						}
						else
						{
							// window.alert( "Your bid is successfully submitted." );
						}							
					}
					
					registerServerMessages( bidderName );
				}
				else 
				{       
				}
			} ).bind( this );

			xhr.onerror = function () 
			{
			};
  
  xhr.send( null );
}

/**
	An admin function to close/stop bidding of a auction item. Once called, all bidders will be 
	notified of the bidding results.
*/
function stopBidding(auctionItemId)
{
	var url = "http://localhost:8888/stopbidding?auctionItemId=" + auctionItemId;        
	var xhr = new XMLHttpRequest();
	var method = "GET"
	xhr.open( method, url );
	xhr.setRequestHeader( "Content-Type", "application/json;charset=UTF-8" );  
	xhr.responseType = "json";
	xhr.onload = ( function () 
		{
			if ( xhr.response !== undefined && xhr.response != null && ( xhr.status === 200 || xhr.status === 0 ) ) 
			{ 	
			}
			else 
			{       
			}
		} ).bind( this );

		xhr.onerror = function () 
		{
		};

  
  xhr.send( null );
}

/**
	An admin function to post an item for auction, with a specified reserve price.
*/
function postForAuction(reservePrice, itemId, description)
{
	var url = "http://localhost:8888/auctionItems";        
	var xhr = new XMLHttpRequest();
	var method = "POST"
	xhr.open( method, url );
	xhr.setRequestHeader( "Content-Type", "application/json;charset=UTF-8" );  
	xhr.responseType = "json";
	xhr.onload = ( function () 
		{
			if ( xhr.response !== undefined && xhr.response != null && ( xhr.status === 200 || xhr.status === 0 ) ) 
			{ 						
				window.alert( "This item has been posted for auction. Auction item ID is: " + xhr.response.auctionItemId ); 						
			}
			else 
			{       
			}
		} ).bind( this );

		xhr.onerror = function () 
		{
		};
  
  var request = {
		  "reservePrice": reservePrice,         
		 "item": {'itemId': itemId, 'description': description}
	  };
  
  xhr.send( JSON.stringify( request ) );
}
  	